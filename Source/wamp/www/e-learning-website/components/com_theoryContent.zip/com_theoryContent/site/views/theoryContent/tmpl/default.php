<?php defined('_JEXEC') or die('Restricted access'); ?>
<h1><?php //echo $this->content ;
			echo $this->theoryName;?></h1>